public class exe02 {
    public static void main(String[] args) {
        
        for (int i = 151; i < 300; i++) {
            System.out.println(i);
        }
    }
}
